import pandas as pd

expected_df=pd.read_csv("C:\spark\convertcsv.csv",usecols=['main/temp','main/temp_min','main/temp_max','main/pressure','main/sea_level'] )

actual_df=pd.read_csv("C:\spark\outputfile.csv",usecols=['main/temp','main/temp_min','main/temp_max','main/pressure','main/sea_level'] )

expected_df.rename(columns={"main/temp": "expected_temp",
                         "main/temp_min": "expected_temp_min",
                         "main/temp_max": "expected_temp_max",
                         "main/pressure": "expected_pressure",
                         "main/sea_level": "expected_sea_level"},inplace=True)

actual_df.rename(columns={"main/temp": "actual_temp",
                         "main/temp_min": "actual_temp_min",
                         "main/temp_max": "actual_temp_max",
                         "main/pressure": "actual_pressure",
                         "main/sea_level": "actual_sea_level"},inplace=True)

df_result_list=[expected_df,actual_df]

df_result = pd.concat(df_result_list)

df_result.to_csv('final_output.csv')


