import pandas as pd

df=pd.read_csv("C:\spark\convertcsv.csv")

print(df.head(5))

print("number of records in file",df.count())


