import requests
import json
import pandas as pd
#API URL
url="https://samples.openweathermap.org/data/2.5/history/city?q=London,UK&appid=b1b15e88fa797225412429c1c50c122a1"


#send get request
response=requests.get(url)
print(response)

#display responce content

data_jason=response.content
print(data_jason)

df_json = pd.read_json(data_jason)
print(df_json)

df_json.to_csv("outputfile.csv")




